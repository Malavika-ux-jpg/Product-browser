-- Products table.
-- id is a BIGSERIAL, so it increases by exactly 1 with every insert, in insertion order.
-- That means "newest first" is simply "ORDER BY id DESC" -- no separate timestamp
-- comparison needed, and it can never be ambiguous (two rows can't share an id).
CREATE TABLE IF NOT EXISTS products (
  id          BIGSERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  category    TEXT NOT NULL,
  price       NUMERIC(10, 2) NOT NULL,
  image_url   TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Safe for databases created from an older version of this schema.
ALTER TABLE products ADD COLUMN IF NOT EXISTS image_url TEXT;

-- Powers plain "newest first" pagination: WHERE id < $cursor ORDER BY id DESC LIMIT $n
CREATE INDEX IF NOT EXISTS idx_products_id_desc ON products (id DESC);

-- Powers category-filtered pagination: WHERE category = $c AND id < $cursor ORDER BY id DESC LIMIT $n
CREATE INDEX IF NOT EXISTS idx_products_category_id_desc ON products (category, id DESC);
