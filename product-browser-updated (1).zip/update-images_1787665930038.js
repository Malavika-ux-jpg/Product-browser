// Adds image_url to an existing products table and assigns a relevant photo
// based on the product noun. Safe to run more than once.
require('dotenv').config();
const pool = require('./db');

const images = {
  Blender: 'https://images.unsplash.com/photo-1570222094114-d054a817e56b?auto=format&fit=crop&w=640&q=80',
  Backpack: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=640&q=80',
  Headphones: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=640&q=80',
  Charger: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=640&q=80',
  Lamp: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=640&q=80',
  Notebook: 'https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=640&q=80',
  Chair: 'https://images.unsplash.com/photo-1503602642458-232111445657?auto=format&fit=crop&w=640&q=80',
  Bottle: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=640&q=80',
  Speaker: 'https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=640&q=80',
  Jacket: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=640&q=80',
  Toolkit: 'https://images.unsplash.com/photo-1581147036324-c17ac41c8b8?auto=format&fit=crop&w=640&q=80',
  Monitor: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=640&q=80',
};

async function updateImages() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('ALTER TABLE products ADD COLUMN IF NOT EXISTS image_url TEXT');

    for (const [noun, imageUrl] of Object.entries(images)) {
      await client.query(
        'UPDATE products SET image_url = $1, updated_at = now() WHERE name LIKE $2',
        [imageUrl, `% ${noun} #%`]
      );
    }

    await client.query('COMMIT');
    const { rows } = await client.query(
      'SELECT COUNT(*)::int AS total, COUNT(image_url)::int AS with_images FROM products'
    );
    console.log(`Updated ${rows[0].with_images} of ${rows[0].total} products with matching images.`);
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

updateImages().catch((error) => {
  console.error('Image update failed:', error.message);
  process.exit(1);
});