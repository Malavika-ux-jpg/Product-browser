require('dotenv').config();
const express = require('express');
const path = require('path');
const pool = require('./db');

const app = express();
app.use(express.static(path.join(__dirname, 'public')));

/**
 * GET /api/products?category=&cursor=&limit=
 *
 * Pagination strategy: keyset (a.k.a. cursor) pagination on `id`, not
 * OFFSET/LIMIT.
 *
 * Why: `id` is a BIGSERIAL, so it's assigned once, in insertion order, and
 * never changes. "Newest first" is just "ORDER BY id DESC". The cursor is the
 * id of the last product the client saw, and each page asks for
 * "id < cursor". Two things fall out of that for free:
 *
 *   1. New products inserted while someone is browsing always get a bigger
 *      id than anything already on screen, so they land above the client's
 *      cursor and never shift already-fetched pages -- no skipped or
 *      duplicated rows, unlike OFFSET pagination where a page shifts by
 *      however many rows were inserted before it.
 *   2. Editing a product (price, name, etc.) only touches `updated_at`, not
 *      `id`, so its position in the "newest first" order never moves either.
 *
 * This also keeps every page fast at any depth: it's an index range scan on
 * idx_products_id_desc (or idx_products_category_id_desc when filtering),
 * not a scan-and-discard OFFSET.
 */
app.get('/api/products', async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit, 10) || 20, 100);
    const category = req.query.category || null;
    const cursor = req.query.cursor ? parseInt(req.query.cursor, 10) : null;

    const conditions = [];
    const params = [];

    if (category) {
      params.push(category);
      conditions.push(`category = $${params.length}`);
    }
    if (cursor) {
      params.push(cursor);
      conditions.push(`id < $${params.length}`);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    params.push(limit);

    const query = `
      SELECT id, name, category, price, image_url, created_at, updated_at
      FROM products
      ${where}
      ORDER BY id DESC
      LIMIT $${params.length}
    `;

    const { rows } = await pool.query(query, params);
    const nextCursor = rows.length === limit ? rows[rows.length - 1].id : null;

    res.json({ products: rows, nextCursor, count: rows.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Something went wrong fetching products.' });
  }
});

// Distinct categories, for the filter dropdown in the UI.
app.get('/api/categories', async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT DISTINCT category FROM products ORDER BY category'
    );
    res.json({ categories: rows.map((r) => r.category) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Something went wrong fetching categories.' });
  }
});

app.get('/api/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
