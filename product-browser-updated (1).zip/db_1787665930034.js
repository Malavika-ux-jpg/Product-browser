require('dotenv').config();
const { Pool } = require('pg');

// A single shared connection pool. Render/Neon/Supabase all give you one
// connection string -- just drop it into DATABASE_URL and this works as-is.
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL && process.env.DATABASE_URL.includes('sslmode=require')
    ? { rejectUnauthorized: false }
    : false,
});

module.exports = pool;
