// Generates products in big batched multi-row INSERTs instead of one INSERT per
// row in a loop (that would mean 200,000 separate round trips to the DB, which
// is slow). Each batch packs BATCH_SIZE rows into a single INSERT statement.
require('dotenv').config();
const fs = require('fs');
const pool = require('./db');

const TOTAL = parseInt(process.env.SEED_COUNT || '200000', 10);
const BATCH_SIZE = 5000;

const CATEGORIES = [
  'Electronics', 'Clothing', 'Home & Kitchen', 'Books', 'Toys',
  'Sports & Outdoors', 'Beauty & Personal Care', 'Grocery', 'Automotive', 'Garden',
];

const ADJECTIVES = [
  'Premium', 'Compact', 'Wireless', 'Portable', 'Ergonomic', 'Classic',
  'Deluxe', 'Eco-Friendly', 'Heavy-Duty', 'Smart', 'Vintage', 'Rapid',
];

const NOUNS = [
  'Blender', 'Backpack', 'Headphones', 'Charger', 'Lamp', 'Notebook',
  'Chair', 'Bottle', 'Speaker', 'Jacket', 'Toolkit', 'Monitor',
];

// Product photos are deliberately keyed by the noun in the generated name.
// The Unsplash CDN URLs are stable and resized at request time.
const PRODUCT_IMAGES = {
  Blender: 'https://images.unsplash.com/photo-1570222094114-d054a817e56b?auto=format&fit=crop&w=640&q=80',
  Backpack: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=640&q=80',
  Headphones: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=640&q=80',
  Charger: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=640&q=80',
  Lamp: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=640&q=80',
  Notebook: 'https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=640&q=80',
  Chair: 'https://images.unsplash.com/photo-1503602642458-232111445657?auto=format&fit=crop&w=640&q=80',
  Bottle: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=640&q=80',
  Speaker: 'https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=640&q=80',
  Jacket: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=640&q=80',
  Toolkit: 'https://images.unsplash.com/photo-1581147036324-c17ac41c8b8?auto=format&fit=crop&w=640&q=80',
  Monitor: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=640&q=80',
};

function randomProduct(i) {
  const category = CATEGORIES[i % CATEGORIES.length];
  const adjective = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
  const noun = NOUNS[Math.floor(Math.random() * NOUNS.length)];
  const name = `${adjective} ${noun} #${i}`;
  const price = (Math.random() * 490 + 9.99).toFixed(2);
  return { name, category, price, image_url: PRODUCT_IMAGES[noun] };
}

async function seed() {
  const client = await pool.connect();
  try {
    console.log(`Seeding ${TOTAL} products in batches of ${BATCH_SIZE}...`);
    const start = Date.now();

    await client.query('TRUNCATE products RESTART IDENTITY');

    for (let offset = 0; offset < TOTAL; offset += BATCH_SIZE) {
      const count = Math.min(BATCH_SIZE, TOTAL - offset);
      const values = [];
      const placeholders = [];

      for (let i = 0; i < count; i++) {
        const p = randomProduct(offset + i);
        const base = i * 4;
        placeholders.push(`($${base + 1}, $${base + 2}, $${base + 3}, $${base + 4})`);
        values.push(p.name, p.category, p.price, p.image_url);
      }

      const query = `INSERT INTO products (name, category, price, image_url) VALUES ${placeholders.join(',')}`;
      await client.query(query, values);

      if ((offset / BATCH_SIZE) % 10 === 0) {
        process.stdout.write(`  ${offset + count}/${TOTAL}\r`);
      }
    }

    const seconds = ((Date.now() - start) / 1000).toFixed(1);
    console.log(`\nDone. Inserted ${TOTAL} products in ${seconds}s.`);
  } finally {
    client.release();
    await pool.end();
  }
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
